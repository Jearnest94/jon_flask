CPACK_STARTUP_SHORTCUTS
-----------------------

.. versionadded:: 3.3

Species a list of shortcut names that should be created in the `Startup` folder
for this file.

The property is currently only supported by the :cpack_gen:`CPack WIX Generator`.
