VS_SHADER_OBJECT_FILE_NAME
--------------------------

.. versionadded:: 3.12

Specifies a file name for the compiled shader object file for an ``.hlsl``
source file.  This adds the ``-Fo`` flag to the command line for the FxCompiler
tool.
