Watcom WMake
------------

Generates Watcom WMake makefiles.
